#Victoria Alvarado 2317120
#create a print number function 
#use a for loop to print the number
#create a odd_even number function
#use a loop to find an odd or even number
#display results
#import ramdon library
#create empty list and counter variable
#use a while loop to interate 10 numbers
#create number variable and asign random int
# append number to nums list
#increase counter variable
#call  print_numbers function
#sort nums list
#call print_numbers function
#create a start list and assign 5 elements
#display start list variable
#create a finish list and assign the last 3 elements
#display a finish list
#call odd_even function

def print_numbers(nums):
    for num in nums:
        print(f'{num}',end= ' ')
    print('\n')
def odd_even(nums):
    even = 0
    odd = 0

    for num in nums:
        if num % 2 == 0:
            even += 1
        else:
            odd += 1
    
    print (f'List had {even} evens and {odd} odds','\n')
    print (f'The 3rd element in sorted nums is {nums[2]}','\n')

import random

def main ():
    nums = []
    counter = 0

    while counter < 10:
        number = random.randint(1,50)
        nums.append(number)
        counter += 1  

    print_numbers(nums)

    nums.sort()

    print_numbers(nums)

    start = nums[0:5]

    print(start,'\n')

    finish = nums[-3:]


    print(finish,'\n')

    odd_even(nums)


if __name__ == '__main__':
    main()