#
# program11.py
# COP 1000 Professor Ma
#
# This program prints the answers to the questions
#

# PSEUDOCODE
#
# Print full name and section number of COP 1000
# Print the name of the function that converts a string to a floating point number
# Print the symbol used to start a Python comment
# Print the name of Python data type for numbers without decimals
# Print the purpose of the \t escape character

# Print answer to question 1
print("My name is Victoria Alvarado COP 1000 Computer Programming")

# Print answer to question 2
print("The float() function can convert strings to a float")

# Print answer to question 3
print("The symbol used to start a comment in Python is the pound symbol \'#\' ")

# Print answer to question 4
print("The Python data type used for numbers is the integer type, whole numbers only")

# Print answer to question 5
print ('The backslash-t escape character is used to insert TAB spaces into outputs\tlike\tthis')

