#Victoria Alvarado 2317120
#use for loop with range of numbers from 3 up to 30 by 3
#Display the numbers on the same line separated by a single space
 
 #The for loop to iterate the range from 3 to 30 
for number in range (3,31,3):
     print (f'{number:1}',end=' ')
#Display number in the same line 
print("\n\n That's all folks!")     
    
