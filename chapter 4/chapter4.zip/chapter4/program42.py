#Victoria Alvarado 2317120
#Use a while loop
#Display table with results

#Create a variable with staring a ending number
starting_number = 5
ending_number = 50
#Use while loop
while starting_number <= ending_number:

#display table with results
    print(f'{starting_number:1}',end=' ')
    starting_number = starting_number + 5