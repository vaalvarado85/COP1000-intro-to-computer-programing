#Victoria Alvarado 2317120
#create two functions to convert fahrenheit or celcius.

def convert_to_fahrenheit(celsius):
    return (celsius*9/5)+ 32

def convert_to_celcius(fahrenheit):
    return (fahrenheit -32)*5/9
    