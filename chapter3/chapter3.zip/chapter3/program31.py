#Victoria Alvarado COP1000
#Get an integer from user
#Determine and display if the integer is odd or even
integer_number = int(input('Enter an integer number'))
remainder = integer_number%2
if remainder== 0:
    print(f"{integer_number} is even.")
else:
     print(f"{integer_number} is odd.")
